﻿using System;
using System.Data.Common;

public class Program
{
    public static void Main(string[] args)
    {

    }
}
