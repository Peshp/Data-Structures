﻿namespace GitHubSystem
{
    public static class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}